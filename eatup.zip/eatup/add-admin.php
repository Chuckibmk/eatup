<?php
    include __DIR__."/data/udata.php";
    $dsbd = 'Add Admin';
    include __DIR__."/master.php";
?>

<body>
    <!-- tap on top start -->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end -->

    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        
        <?php
            include __DIR__."/header.php";
        ?>

        <!-- Page Body Start-->
        <div class="page-body-wrapper">
            <?php
                include __DIR__."/sidebar.php";
            ?>
            
            <!-- Page Sidebar Start -->
            <div class="page-body">
                <!-- New User start -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-sm-8 m-auto">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="title-header option-title">
                                                <h5>Add New Admin</h5>
                                            </div>
                                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link active" id="pills-home-tab"
                                                        data-bs-toggle="pill" data-bs-target="#pills-home"
                                                        type="button">Account</button>
                                                </li>
                                                <!--<li class="nav-item" role="presentation">-->
                                                <!--    <button class="nav-link" id="pills-profile-tab"-->
                                                <!--        data-bs-toggle="pill" data-bs-target="#pills-profile"-->
                                                <!--        type="button">Pernission</button>-->
                                                <!--</li>-->
                                            </ul>

                                            <div class="tab-content" id="pills-tabContent">
                                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel">
                                                    <form class="theme-form theme-form-2 mega-form">
                                                        <div class="card-header-1">
                                                            <h5>Admin Information</h5>
                                                        </div>

                                                        <div class="row">
                                                            <div class="mb-4 row align-items-center">
                                                                <label
                                                                    class="form-label-title col-lg-2 col-md-3 mb-0">User Name</label>
                                                                <div class="col-md-9 col-lg-10">
                                                                    <input id="uname" class="form-control" type="text">
                                                                </div>
                                                            </div>

                                                            <div class="mb-4 row align-items-center">
                                                                <label
                                                                    class="col-lg-2 col-md-3 col-form-label form-label-title">Email
                                                                    Address</label>
                                                                <div class="col-md-9 col-lg-10">
                                                                    <input id="email" class="form-control" type="email">
                                                                </div>
                                                            </div>

                                                            <div class="mb-4 row align-items-center">
                                                                <label
                                                                    class="col-lg-2 col-md-3 col-form-label form-label-title">Password</label>
                                                                <div class="col-md-9 col-lg-10">
                                                                    <input id="password" class="form-control" type="password">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-submit-button">
                                            <button onclick="addadmin()" id="btnadmin" class="btn btn-animation ms-auto" type="button">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- New User End -->

            </div>
            <!-- Page Sidebar End -->

        </div>
        <!-- Page Body End -->
    </div>
    <!-- page-wrapper End-->
    
    <?php
        include __DIR__."/footer.php";
    ?>
    <script>
        function addadmin() {

            let uname = $('#uname').val().trim();
            let email = $('#email').val().trim();
            let pass = $('#password').val().trim();
        
            if (uname.length === 0 || email.length === 0 || pass.length === 0) {
                Swal.fire({
                    text:"Fill all fields!!!",
                    icon:"warning",
                    color:"white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                })
                return;
            }
            if (pass.length < 6) {
                Swal.fire({
                    text:"Password must be more than 6 characters!!!",
                    icon:"warning",
                    color:"white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                })
                return;
            }
            $("#btnadmin").html('<span class="">Registering...</span>');
            $.ajax({
                url: 'data/register.php',
                type: 'post',
                dataType: 'json',
                data: {
                    uname: uname,
                    email: email,
                    pass: pass
                },
                success: function (response) {
                    if (response.stat === "one") {
                        Swal.fire({
                            title: "Successful",
                            text: response.msg, 
                            icon: "success",
                            color:"white",
                            confirmButtonColor: '#272a42',
                            background: "linear-gradient(45deg, #272a42, #51ade5)"
                            
                        }).then(function() {
                            window.location = "index.php";
                        });
                    }else if (response.stat === "two") {
                            Swal.fire({
                            title: "Please note",
                            text: response.msg, 
                            icon: "info",
                            color:"white",
                            confirmButtonColor: '#272a42',
                            background: "linear-gradient(45deg, #272a42, #51ade5)"
                            
                        }).then(function() {
                            window.location = "index.php";
                        });
                        $("#btn-register").html('Register');
                    }else {
                        console.log(response);
                        Swal.fire({
                            title: "Error",
                            text: 'Server error, try again later',
                            icon: "error",
                            color:"white",
                            confirmButtonColor: '#272a42',
                            background: "linear-gradient(45deg, #272a42, #51ade5)"
                        }).then(function() {
                            window.location = "index.php";
                        });
                    }
                }
            });
        }
    </script>
</body>

</html>