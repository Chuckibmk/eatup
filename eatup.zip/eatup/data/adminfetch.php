<?php

if(isset($_POST['load'])){
    $_SESSION['loaded_user'] = $_POST['id'];
    exit(header("Location: index.php"));
}elseif(isset($_POST['makeAdmin'])){
    $user->makeAdmin($_POST['id']);
    exit(header("Location: index.php"));
//    exit();
}elseif(isset($_POST['removeAdmin'])) {
    $user->makeUser($_POST['id']);
    exit(header("Location: index.php"));
}elseif(isset($_POST['deleteUser'])){
    $user->deleteUser($_POST['id']);
    exit(header("location: index.php"));
}

$users = $user->allUsers();
$admins = $user->allAdmins();
$pDeposits = $user->pendingDeposit();
$aDeposits = $user->approvedDeposit();
$pWithdrawals = $user->pendingWithdrawal();
$aWithdrawals = $user->approvedWithdrawal();
$pContracts = $user->pendingContracts();
$aContracts = $user->approvedContracts();
$pendingKYC = $user->pendingKYC();
$KYC = $user->KYC();
$wallet = $user->wallet();


if(isset($_POST['walme'])){
    $walme = $_POST["walme"];
    $wallad = $_POST["wallad"];
    $user->addWallet($walme,$wallad);
    header("Location: index.php");
}

if(isset($_POST['wid'])){
    $wid = $_POST["wid"];
    $user->delWal($wid);
    header("Location: index.php");
}

if(isset($_POST['wame'])){
    $wame = $_POST["wame"];
    $addr = $_POST["wadd"];
    $weid = $_POST["weid"];
    $user->upWall($weid,$wame,$addr);
    header("Location: index.php");
}
