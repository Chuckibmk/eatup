<?php
require_once "udata.php";
require_once "../class/dashboard.php";


if(isset($_POST['title'], $_POST['detail'])){
    
    $return = [];
    $total = count($_FILES['file']['name']);
    $new_filenames = []; // Initialize an empty array to store filenames
    
    // Loop through each file
    for( $i=0 ; $i < $total ; $i++ ) {
    
      //Get the temp file path
      $pic_temp = $_FILES['file']['tmp_name'][$i];
      $pic_size = $_FILES['file']['size'][$i];
      $picname = $_FILES['file']['name'][$i];
    
        if ($pic_size > 0) {
            if (!empty($picname)) {
                $extn = $user->extensionName($picname);
                if (($extn != '0')) {
                    $newname = $user->imageCName($i) . '.' . $extn;
                    // $newname = $_POST['title']. '/' . $newn;
                    $destination = '../uploads/' .$_POST['title'].'/'.$newname;
                    
                    // Create the folder if it doesn't exist
                    if (!is_dir('../uploads/' . $_POST['title'])) {
                        mkdir('../uploads/' . $_POST['title'], 0777, true);
                    }

                    if (move_uploaded_file($pic_temp, $destination)) {
                        //return $newname
                        $new_filenames[] = $newname;
                    } else {
                        $return['stat'] = "two";
                        $return['msg'] = 'Picture Upload Failed for file: ' . $picname;
                    }
                } else {
                    $return['stat'] = "two";
                    $return['msg'] = 'Please Use a Valid Image extension. eg: png,jpg,gif,jpeg.';
                }
            } else {
                $return['stat'] = "two";
                $return['msg'] = 'Please Browse a Valid File!';
            }
        }
    }
    if(!empty($new_filenames)){
        $result = $user->addItem($_POST['title'],$_POST['detail'],$_POST['price'],implode(",",$new_filenames),$_POST['cate'],$_POST['shop'],$_POST['tab'],$_POST['sku'],$_POST['stock']);
        if(!empty($result)){
            $return['stat'] = "one";
            $return['msg'] = 'Product created';
        }
        
    }else {
        $return['stat'] = "two";
        $return['msg'] = 'Please select at least one file to upload.';
    }
    echo json_encode($return);
}