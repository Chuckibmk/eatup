<?php
require_once "udata.php";
require_once "../class/dashboard.php";


if(isset($_POST['title'], $_POST['subt'])){
    
    $return = [];
    $total = count($_FILES['file']['name']);
    $new_filenames = []; // Initialize an empty array to store filenames
    
    // Loop through each file
    for( $i=0 ; $i < $total ; $i++ ) {
    
      //Get the temp file path
      $pic_temp = $_FILES['file']['tmp_name'][$i];
      $pic_size = $_FILES['file']['size'][$i];
      $picname = $_FILES['file']['name'][$i];
    
        if ($pic_size > 0) {
            if (!empty($picname)) {
                $extn = $user->extensionName($picname);
                if (($extn != '0')) {
                    $newname = $user->imageCName($i) . '.' . $extn;
                    $destination = '../uploads/' .$_POST['title'].'/'.$newname;
                    
                    // Create the folder if it doesn't exist
                    if (!is_dir('../uploads/' . $_POST['title'])) {
                        mkdir('../uploads/' . $_POST['title'], 0777, true);
                    }

                    if (move_uploaded_file($pic_temp, $destination)) {
                        //return $newname
                        $new_filenames[] = $newname;
                    } else {
                        $return['msg'] = 'Picture Upload Failed for file: ' . $picname;
                    }
                } else {
                    $return['msg'] = 'Please Use a Valid Image extension. eg: png,jpg,gif,jpeg.';
                }
            } else {
                $return['msg'] = 'Please Browse a Valid File!';
            }
        }
    }
    if(!empty($new_filenames)){
        $result = $user->addShop($_POST['title'],$_POST['subt'],$_POST['desc'],$_POST['tab'],$_POST['cate'],implode(",",$new_filenames));
        
        if(!empty($result)){
            $return['stat'] = "one";
            $return['msg'] = 'Shop created';
        }
        
    }else {
        $return['msg'] = 'Please select at least one file to upload.';
    }
    echo json_encode($return);
}