 <?php
    include __DIR__."/data/udata.php";
    $dsbd = 'Category';
    include __DIR__."/master.php";
?>

<body>
    <!-- tap on top start -->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end -->

    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        
        <?php
            include __DIR__."/header.php";
        ?>

        <!-- Page Body Start-->
        <div class="page-body-wrapper">
            <?php
                include __DIR__."/sidebar.php";
            ?>
    

            <div class="page-body">

                <!-- New Product Add Start -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-sm-8 m-auto">
                                    <div class="card">
                                        <form method="post" enctype="multipart/form-data"  action="">
                                        <div class="card-body">
                                            <div class="card-header-2">
                                                <h5>Category Information</h5>
                                            </div>

                                            <div class="theme-form theme-form-2 mega-form">
                                                <div class="mb-4 row align-items-center">
                                                    <label class="form-label-title col-sm-3 mb-0">Category Title</label>
                                                    <div class="col-sm-9">
                                                        <input id="title" name="title" class="form-control" type="text"
                                                            placeholder="Category Name">
                                                    </div>
                                                </div>
                                                <div class="mb-4 row align-items-center">
                                                    <label class="form-label-title col-sm-3 mb-0">Category Subtitle</label>
                                                    <div class="col-sm-9">
                                                        <input id="subt" name="subtitle" class="form-control" type="text"
                                                            placeholder="Category Name">
                                                    </div>
                                                </div>

                                                <div class="mb-4 row align-items-center">
                                                    <label class="col-sm-3 col-form-label form-label-title">Category
                                                        Image</label>
                                                        <div class="col-sm-9">
                                                        <input name="file[]" class="form-control form-choose" type="file"
                                                            id="formFile" multiple>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="card-submit-button">
                                            <button class="btn btn-animation ms-auto" onclick="addcategory()" id="btncat" type="button">Submit</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- New Product Add End -->

            </div>
            <!-- Container-fluid End -->
        </div>
        <!-- Page Body End -->
    </div>
    <!-- page-wrapper End-->
    
    <?php
        include __DIR__."/footer.php";
    ?>
    <script>
    function addcategory() {
    let title = $('#title').val().trim();
    let subt = $('#subt').val().trim();
    const fileInput = document.getElementById('formFile');

    if (!fileInput) {
        console.error("File input element not found!");
        return;
    }

    let formFile = fileInput.files;
    const formData = new FormData();
    
    formData.append('title', title);
    formData.append('subt', subt);

    for (let i = 0; i < formFile.length; i++) {
        formData.append('file[]', formFile[i]);
    }

    if (title.length === 0 || subt.length === 0 || formFile.length === 0) {
        Swal.fire({
            text: "Fill all fields!!!",
            icon: "warning",
            color: "white",
            confirmButtonColor: '#272a42',
            background: "linear-gradient(45deg, #272a42, #51ade5)"
        });
        return;
    }

    $("#btncat").prop('disabled', true).html('<span class="">Registering...</span>');

    $.ajax({
        url: 'data/addcategory.php',
        type: 'post',
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            try {
                response = JSON.parse(response);
            } catch (e) {
                console.error("Invalid JSON response:", response);
                Swal.fire({
                    title: "Error",
                    text: "Invalid response from server",
                    icon: "error",
                    color: "white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                });
                $("#btncat").prop('disabled', false).html('Register');
                return;
            }

            if (response.stat === "one") {
                Swal.fire({
                    title: "Successful",
                    text: response.msg,
                    icon: "success",
                    color: "white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                }).then(function () {
                    window.location = "index.php";
                });
            } else if (response.stat === "two") {
                Swal.fire({
                    title: "Please note",
                    text: response.msg,
                    icon: "info",
                    color: "white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                }).then(function () {
                    window.location = "index.php";
                });
                $("#btncat").prop('disabled', false).html('Register');
            } else {
                console.log(response);
                Swal.fire({
                    title: "Error",
                    text: "Server error, try again later",
                    icon: "error",
                    color: "white",
                    confirmButtonColor: '#272a42',
                    background: "linear-gradient(45deg, #272a42, #51ade5)"
                }).then(function () {
                    window.location = "index.php";
                });
                $("#btncat").prop('disabled', false).html('Register');
            }
        },
        error: function () {
            Swal.fire({
                title: "Error",
                text: "Request failed, please try again later.",
                icon: "error",
                color: "white",
                confirmButtonColor: '#272a42',
                background: "linear-gradient(45deg, #272a42, #51ade5)"
            });
            $("#btncat").prop('disabled', false).html('Register');
        }
    });
}

    </script>
</body>

</html>