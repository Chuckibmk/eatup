 <?php
    include __DIR__."/data/udata.php";
    $dsbd = 'Category';
    include __DIR__."/master.php";
?>

<body>
    <!-- tap on top start -->
    <div class="tap-top">
        <span class="lnr lnr-chevron-up"></span>
    </div>
    <!-- tap on tap end -->

    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
        
        <?php
            include __DIR__."/header.php";
        ?>

        <!-- Page Body Start-->
        <div class="page-body-wrapper">
            <?php
                include __DIR__."/sidebar.php";
            ?>
    
            <!-- Container-fluid starts-->
            <div class="page-body">
                <!-- All User Table Start -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card card-table">
                                <div class="card-body">
                                    <div class="title-header option-title">
                                        <h5>All Category</h5>
                                        <form class="d-inline-flex">
                                            <a href="add-new-category.php"
                                                class="align-items-center btn btn-theme d-flex">
                                                <i data-feather="plus-square"></i>Add New
                                            </a>
                                        </form>
                                    </div>

                                    <div class="table-responsive category-table">
                                        <div>
                                            <table class="table all-package theme-table" id="table_id">
                                                <thead>
                                                    <tr>
                                                        <th>Image</th>
                                                        <th>Name</th>
                                                        <th>Subtitle</th>
                                                        <th>Option</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php
                                                    foreach($sections as $s){
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <div class="table-image">
                                                                <img src="uploads/<?=$s['name']?>/<?=$s['image']?>" class="img-fluid"
                                                                    alt="">
                                                            </div>
                                                        </td>
                                                        <td><?=$s['name']?></td>

                                                        <td><?=$s['subtitle']?></td>

                                                        
                                                        <td>
                                                            <ul>
                                                                

                                                                <li>
                                                                    <a href="javascript:void(0)">
                                                                        <i class="ri-pencil-line"></i>
                                                                    </a>
                                                                </li>

                                                                <li>
                                                                    <a href="javascript:void(0)" data-bs-toggle="modal"
                                                                        data-bs-target="#exampleModalToggle">
                                                                        <i class="ri-delete-bin-line"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- All User Table Ends-->

            </div>
            <!-- Container-fluid end -->
        
         </div>
        <!-- Page Body End -->
    </div>
    <!-- page-wrapper End-->
    
    <?php
        include __DIR__."/footer.php";
    ?>
</body>

</html>