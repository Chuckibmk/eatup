<?php

include __DIR__ . "/../database/database.php";

class dashboard extends database
{
    //////eatup
    
    
    public function Admins()
	{
		$sql = "SELECT *
				FROM admin 
		";
		return $this->getRows($sql);
	}
    public function Sections()
	{
		$sql = "SELECT *
				FROM sections 
		";
		return $this->getRows($sql);
	}
	public function addSection($name,$st,$im)
    {
        $sql = "INSERT INTO sections (name,subtitle,image,uqid) 
                VALUES (?,?,?,?)
		";
        return $this->insertRow($sql, [$name,$st,$im,substr($name,0,2).rand(0000, 9999)]);
    }
    
    public function Shops()
	{
		$sql = "SELECT *
				FROM shops 
		";
		return $this->getRows($sql);
	}
	public function addShop($name,$st,$dc,$t,$s,$im)
    {
        $sql = "INSERT INTO shops (name,subtitle,description,tabs,section,image,uqid,date) 
                VALUES (?,?,?,?,?,?,?,?)
		";
        return $this->insertRow($sql, [$name,$st,$dc,$t,$s,$im,substr($s,0,2).rand(0000, 9999),time()]);
    }
    public function Items()
	{
		$sql = "SELECT *
				FROM items 
		";
		return $this->getRows($sql);
	}
	public function addItem($name,$dt,$pc,$im,$ct,$sp,$tb,$su,$ss)
    {
        $sql = "INSERT INTO items (name,details,price,image,category,shop,tabs,sku,stock_status,uqid,date) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
		";
        return $this->insertRow($sql, [$name,$dt,$pc,$im,$ct,$sp,$tb,$su,$ss,substr($sp,0,2).rand(0000, 9999),time()]);
    }
	////////uploading image
	public function imageCName($i)
    {
        $prefix = 'IMAGE'.$i;
        $suffix = uniqid();
        return ($prefix . $suffix);
    }
	public function extensionName($filename)
    {
        $extension = explode(".", $filename);
        $new = end($extension);
        if (strtolower($new) === 'jpg' || strtolower($new) === 'png' || strtolower($new) === 'gif' || strtolower($new) === 'jpeg' || strtolower($new) === 'webp') {
            return $new;
        } else {
            return (0);
        }
    }
    ////////////////////////////////////////
}
$user = new Dashboard();