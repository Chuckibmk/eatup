<?php
// website
// define("DOMAIN","localhost/globalcap");
define("DOMAIN", $_SERVER['HTTP_HOST']);