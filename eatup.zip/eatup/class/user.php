<?php

require_once '../database/database.php';
class user extends database{
    public function Admins()
	{
		$sql = "SELECT *
				FROM admin 
		";
		return $this->getRows($sql);
	}
    public function loginAdmin($un, $pwd)
	{
		$sql = "SELECT *
				FROM admin 
				WHERE username = ?
				AND password = ?;
		";
		return $this->getRow($sql, [$un, $pwd]);
	}
	 public function adminExists($mail){
        $sql = "SELECT id
				FROM admin 
				WHERE email = ?
		";
        return $this->getRow($sql, [$mail]);
    }
    
    public function registerAdmin($a)
    {
        $sql = "INSERT INTO admin (email, password, pass, username, adminUQID) 
                VALUES (?,?,?,?,?);
		";
        try {
            $this->insertRow($sql, [$a['email'], md5($a['pass']), $a['pass'], $a['uname'], "EA".rand(8888, 9999)]);
            return $this->lastID();
        } catch (Exception $e) {
            return false;
        }
        
    }
    
    ///////////////////////notification///////////////////////

    public function refExists($refID){
        $sql = "SELECT id
				FROM users 
				WHERE userid = ?
		";
        return $this->getRow($sql, [$refID])['id'];
    }

    public function changePassword($pwd,$token)
    {
        $sql = "UPDATE users 
                SET password
				 = ? WHERE email_ver_code = ?
		";
        return $this->updateRow($sql, [$pwd,$token]);
    }
    
    public function verifyCode($vercode)
    {
        $sql = "SELECT fname
				FROM users 
				WHERE email_ver_code = ?
				";

        return $this->getRow($sql, [$vercode]);
    }
    
    public function evVerified($code)
    {
        $sql = "UPDATE users 
                SET es
				 = 1 WHERE email_ver_code = ?
		";
        return $this->updateRow($sql, [$code]);
    }
    
    public function passChangeRequest($email)
    {
        $sql = "UPDATE users 
                SET email_ver_code
				 = ? WHERE email = ?
		";
        return $this->updateRow($sql, [$email]);
    }
}

$user = new User();
